# boucle d'attente tant que l'uitlisateur n'a pas saisi 100

n=-1

while n!=100:
    n=int(input("saisir une valeur entière "))

print ("bravo, vous savez saisi 100 !!!")