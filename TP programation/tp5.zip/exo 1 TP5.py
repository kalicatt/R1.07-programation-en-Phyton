first_prenom = str(input("entrez le prenom de la personne n°1 : \n"))
first_nom = str(input("entrez le nom de la personne n°1 : \n"))

second_prenom = str(input("entrez le prenom de la personne n°2 : \n"))
second_nom = str(input("entrez le nom de la personne n°2 : \n"))

if first_nom < second_nom:
    print(str.capitalize(first_prenom),str.upper(first_nom))
    print(str.capitalize(second_prenom),str.upper(second_nom))
    
if first_nom == second_nom:
    if first_prenom < second_prenom:
        print(str.capitalize(first_prenom),str.upper(first_nom))
        print(str.capitalize(second_prenom),str.upper(second_nom))
    else: 
        print(str.capitalize(second_prenom),str.upper(second_nom))
        print(str.capitalize(first_prenom),str.upper(first_nom))
else:
    print(str.capitalize(second_prenom),str.upper(second_nom))
    print(str.capitalize(first_prenom),str.upper(first_nom))