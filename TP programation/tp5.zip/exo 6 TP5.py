T = input("Entrez la chaîne de caractères : ")
taille = 0
for i in T:
    if i != '\0': # On ne compte pas le caractère de fin de chaîne
        taille += 1
print(f"La taille de la chaîne est {taille}.")


T = input("Entrez la chaîne de caractères : ")
nb_voyelles = 0
for i in T:
    if i in ['a','e','i','o','u','A','E','I','O','U'] and i != '\0': 
        nb_voyelles += 1
pourcentage = (nb_voyelles/taille)*100
print(f"Le pourcentage de voyelles dans la chaîne est {pourcentage}.")


T = input("Entrez la chaîne de caractères : ")
occurence = 0
for i in range(len(T)-len('wagon')+1):
    if T[i:i+len('wagon')] == "wagon":
        occurence += 1
        print(f"La chaine 'wagon' est une sous-chaine de T, elle commence à l'index {i}.")
        break
if occurence == 0:
    print("La chaine 'wagon' n'est pas une sous-chaine de T.")


print(f"La taille de la chaîne est {taille}.",)