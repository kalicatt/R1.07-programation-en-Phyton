# On lit le nombre d'heures travaillées
heures_travaillees = int(input("Entrez le nombre d'heures travaillées : "))

# On lit le salaire horaire
salaire_horaire = float(input("Entrez le salaire horaire : "))

# On calcule le salaire en fonction des heures travaillées
if heures_travaillees <= 160:
    salaire = heures_travaillees * salaire_horaire
elif heures_travaillees <= 200:
    salaire = 160 * salaire_horaire + (heures_travaillees - 160) * salaire_horaire * 1.25
else:
    salaire = 160 * salaire_horaire + 40 * salaire_horaire * 1.25 + (heures_travaillees - 200) * salaire_horaire * 1.5

# On affiche le salaire
print(f"Le salaire de l'ouvrier est de {salaire} euros.")

