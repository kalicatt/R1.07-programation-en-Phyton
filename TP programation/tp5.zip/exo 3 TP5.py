Test = str(input("entrez la phrase a tester : \n"))
t2=""

for i in range (len(Test)):
    if Test[i].isalpha():
        t2+= Test[i]
        
print(f"String corrigé = {t2}")
t2 = t2.lower()

if  (len(t2) % 2)== 0:
    
    for x in range(int(len(t2)/2)):
        print(x)
        
        if t2[x] != t2[(len(t2)-x)-1]:
            print("la chaine n'est pas un palyndrome !")
            break
        else:
            print("la chaine est un palyndrome !")
else:
    
    for x in range(int(len(t2)/2)):
        
        if x == len(t2) - x:
            print("la chaine est un palyndrome !")
            break
        
        if t2[x] != t2[(len(t2)-x)-1]:
            print("la chaine n'est pass un palyndrome !")
            break
        
