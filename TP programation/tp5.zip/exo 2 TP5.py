gradeT = []

moyenne = 0.00

for i in range(5):
    grades = str(input("veuillez entrer la note puis le coeff : \n"))
    gradeT.append(grades)
    
print(gradeT)

for x in range(0,5):
    
    S = gradeT[x].split(" ")
    S[0] = int(S[0])
    S[1] = int(S[1])
    
    if moyenne == 0.00:
        moyenne = (S[0] * S[1]) /  S[1]
    else:
        moyenne =(((S[0] * S[1]) /  S[1]) + moyenne) / 2
        
print(f"Votre moyenne est de : {moyenne}") 
        