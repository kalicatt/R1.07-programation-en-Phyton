from random import randint

alea = randint(0,100)

if alea < 50:
    print("pile")
else:
    print("face")
    