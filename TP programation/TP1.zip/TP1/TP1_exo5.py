from random import randint

alea = randint(0,100)

print(f"valeur aléatoire {alea}")
