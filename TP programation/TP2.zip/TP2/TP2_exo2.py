age = int(input("Donnez votre age"))
annee = 2021-age

print(f"Votre année de naissance est {annee}")